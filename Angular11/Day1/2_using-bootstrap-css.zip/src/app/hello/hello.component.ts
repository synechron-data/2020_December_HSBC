import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'app-hello',
  template: `
    <div class="container">
      <h1 class="text-info">Hello World!</h1>
    </div>
  `
})
export class HelloComponent implements OnInit {
  constructor() { }

  ngOnInit(): void {
  }
}
