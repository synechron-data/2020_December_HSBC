import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'root',
  template: `
    <div class="container">
      <comp-one></comp-one>
      <comp-two></comp-two>
      <hr />
      <comp-one></comp-one>
      <comp-two></comp-two>
    </div>
  `,
  styles: [
  ]
})
export class RootComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
