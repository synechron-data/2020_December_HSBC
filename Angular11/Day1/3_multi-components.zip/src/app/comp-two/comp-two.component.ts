import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'comp-two',
  template: `
    <h1 class="text-success">Hello from Component Two</h1>
  `,
  styles: [
  ]
})
export class CompTwoComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
