// import { BrowserModule } from '@angular/platform-browser';
// import { NgModule } from '@angular/core';
// import { CompOneComponent } from './comp-one/comp-one.component';
// import { CompTwoComponent } from './comp-two/comp-two.component';

// @NgModule({
//   declarations: [CompOneComponent, CompTwoComponent],
//   imports: [BrowserModule],
//   providers: [],
//   bootstrap: [CompOneComponent, CompTwoComponent]
// })
// export class AppModule { }

// --------------------------------------------------------------------

import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { CompOneComponent } from './comp-one/comp-one.component';
import { CompTwoComponent } from './comp-two/comp-two.component';
import { RootComponent } from './root/root.component';

@NgModule({
  declarations: [CompOneComponent, CompTwoComponent, RootComponent],
  imports: [BrowserModule],
  providers: [],
  bootstrap: [RootComponent]
})
export class AppModule { }
