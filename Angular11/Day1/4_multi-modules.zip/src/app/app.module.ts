import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RootComponent } from './root/root.component';
import { MOneModule } from './m-one/m-one.module';
import { MTwoModule } from './m-two/m-two.module';

@NgModule({
  declarations: [RootComponent],
  imports: [BrowserModule, MOneModule, MTwoModule],
  providers: [],
  bootstrap: [RootComponent]
})
export class AppModule { }
