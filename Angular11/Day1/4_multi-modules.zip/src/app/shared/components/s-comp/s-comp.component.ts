import { Component, OnInit } from '@angular/core';

@Component({
  selector: 's-comp',
  template: `
    <h3 class="text-warning">I am the Shared Component from Shared Module</h3>
  `,
  styles: [
  ]
})
export class SCompComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
