import { Component, OnInit } from '@angular/core';

@Component({
  selector: 'hello',
  template: `
    <h2 class="text-success">Local Hello Component - M2</h2>
  `,
  styles: [
  ]
})
export class HelloComponent implements OnInit {

  constructor() { }

  ngOnInit(): void {
  }

}
