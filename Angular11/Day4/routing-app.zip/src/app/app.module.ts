import { BrowserModule } from '@angular/platform-browser';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { HttpClientModule, HTTP_INTERCEPTORS } from "@angular/common/http";
import { NgModule } from '@angular/core';
import { RootComponent } from './components/root/root.component';
import { BsNavComponent } from './components/bs-nav/bs-nav.component';
import { AppRoutingModule } from './app-routing.module';
import { HomeComponent } from './components/home/home.component';
import { AboutComponent } from './components/about/about.component';
import { NotFoundComponent } from './components/not-found/not-found.component';
import { AuthorsModuleModule } from './authors-module/authors-module.module';
import { ProductsComponent } from './components/products/products.component';
import { ProductNotSelectedComponent } from './components/product-not-selected/product-not-selected.component';
import { ProductDetailsComponent } from './components/product-details/product-details.component';
import { AdminComponent } from './components/admin/admin.component';
import { LoginComponent } from './components/login/login.component';
import { TokenInterceptorService } from './services/token-interceptor.service';

@NgModule({
  declarations: [RootComponent, BsNavComponent, HomeComponent, AboutComponent, NotFoundComponent,
    ProductsComponent, ProductNotSelectedComponent, ProductDetailsComponent, AdminComponent, LoginComponent],
  imports: [BrowserModule, FormsModule, ReactiveFormsModule, HttpClientModule, AppRoutingModule,
    AuthorsModuleModule],
  providers: [
    {
      provide: HTTP_INTERCEPTORS,
      multi: true,
      useClass: TokenInterceptorService
    }
  ],
  bootstrap: [RootComponent]
})
export class AppModule { }
