var express = require('express');
var router = express.Router();
var cors = require('cors');

const users_api_ctrl = require('../controllers/users-api-controller');
const acc_ctrl = require('../controllers/account-controller');

router.use(cors());

router.use(acc_ctrl.validateToken);

// GET - /api/users (Get All users)
router.get('/', users_api_ctrl.getUsers);

// GET - /api/users/:userid  (Get single user by id)
router.get('/:userid', users_api_ctrl.getUser);

// POST - /api/users     (Create an user)
router.post('/', users_api_ctrl.createUser);

// PUT - /api/users/:userid  (Update an user)
router.put('/:userid', users_api_ctrl.updateUser);

// DELETE - /api/users/:userid   (Delete an user)
router.delete('/:userid', users_api_ctrl.deleteUser);

module.exports = router;
