var express = require('express');
var router = express.Router();

const users_ctrl = require('../controllers/users-controller');
const acc_ctrl = require('../controllers/account-controller');

router.use(acc_ctrl.isAuthenticated);

router.get('/', users_ctrl.index);

module.exports = router;
