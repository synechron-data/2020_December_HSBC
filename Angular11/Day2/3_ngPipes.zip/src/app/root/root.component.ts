import { Component, QueryList, ViewChild, ViewChildren } from '@angular/core';

@Component({
  selector: 'root',
  templateUrl: './root.component.html',
})
export class RootComponent {
  name: string;
  num: number;
  person: { id: number, name: string, address: { city: string, pin: number } };
  today: Date;
  flag: boolean;
  pList:Array<string>;

  constructor() {
    this.name = "manish sharma";
    this.num = Math.PI;
    this.person = { id: 1, name: "Manish", address: { city: "Pune", pin: 411021 } };
    this.today = new Date();
    this.flag = true;
    this.pList = ["Manish", "Abhijeet", "Kedar", "Avinash", "Mohit", "Ashish", "Ankur", "Kumud"];
  }

  get format() { return this.flag && 'fullDate' || 'shortDate'; }

  updateFlag() {
    this.flag = !this.flag;
  }
}
