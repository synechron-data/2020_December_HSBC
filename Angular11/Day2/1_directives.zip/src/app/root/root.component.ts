import { Component } from '@angular/core';

@Component({
  selector: 'root',
  templateUrl: './root.component.html',
})
export class RootComponent {
  flag: boolean;
  myStyles: any;
  name: string;

  constructor() {
    this.flag = false;

    this.myStyles = {
      'background-color': 'green',
      'font-size': '20px',
      'color': 'white'
    };

    // this.name = "Synechron";
    this.name = "";
  }
}
