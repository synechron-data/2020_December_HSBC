import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RootComponent } from './root/root.component';
import { FormsModule } from '@angular/forms';
import { AssignTwoComponent } from './assign-two/assign-two.component';
import { ListComponent } from './list/list.component';
import { ChangeContentDirective } from './directives/change-content.directive';
import { HighlightDirective } from './directives/highlight.directive';

@NgModule({
  declarations: [RootComponent, AssignTwoComponent, ListComponent, ChangeContentDirective, HighlightDirective],
  imports: [BrowserModule, FormsModule],
  providers: [],
  bootstrap: [RootComponent]
})
export class AppModule { }
