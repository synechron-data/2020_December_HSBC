import { Component, QueryList, ViewChild, ViewChildren } from '@angular/core';

@Component({
  selector: 'root',
  templateUrl: './root.component.html'
})
export class RootComponent {
  constructor() {
  }
}
