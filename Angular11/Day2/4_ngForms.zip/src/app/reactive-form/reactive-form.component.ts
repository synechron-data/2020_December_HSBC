import { Component, OnInit } from '@angular/core';
import { FormGroup, FormBuilder } from '@angular/forms';

@Component({
  selector: 'reactive-form',
  templateUrl: './reactive-form.component.html',
  styles: [
  ]
})
export class ReactiveFormComponent implements OnInit {
  regForm: FormGroup;

  constructor(private frmBuilder: FormBuilder) {
    this.regForm = this.frmBuilder.group({
      firstname: "",
      lastname: "",
      address: this.frmBuilder.group({
        city: "",
        zip: 0
      })
    });
  }

  ngOnInit(): void { }

  logForm() {
    if (this.regForm)
      console.log(this.regForm.value);
  }

  reset() {
    this.regForm.reset();
  }

  set() {
    this.regForm.setValue({
      firstname: "Abhjeet",
      lastname: "Gole",
      address: {
        city: "Pune",
        zip: 411029
      }
    })
  }

  patch() {
    this.regForm.patchValue({
      firstname: "Abhjeet",
      lastname: "Gole"
    })
  }
}

// -------------------------------------------------------------
// import { Component, OnInit } from '@angular/core';
// import { FormControl, FormGroup } from '@angular/forms';

// @Component({
//   selector: 'reactive-form',
//   templateUrl: './reactive-form.component.html',
//   styles: [
//   ]
// })
// export class ReactiveFormComponent implements OnInit {
//   regForm: FormGroup;

//   constructor() {
//     this.regForm = new FormGroup({
//       firstname: new FormControl(),
//       lastname: new FormControl(),
//       address: new FormGroup({
//         city: new FormControl(),
//         zip: new FormControl()
//       })
//     });
//   }

//   ngOnInit(): void { }

//   logForm() {
//     if (this.regForm)
//       console.log(this.regForm.value);
//   }
// }
