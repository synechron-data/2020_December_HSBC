import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RootComponent } from './root/root.component';
import { FormsModule } from '@angular/forms';
import { ListComponent } from './list/list.component';
import { CounterComponent } from './counter/counter.component';

@NgModule({
  declarations: [RootComponent, ListComponent, CounterComponent],
  imports: [BrowserModule, FormsModule],
  providers: [],
  bootstrap: [RootComponent]
})
export class AppModule { }
