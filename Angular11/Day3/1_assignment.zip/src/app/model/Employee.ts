export interface Employee {
    empid: number;
    empname: string;
    designation: string;
    salary: number;
}