import { Component, EventEmitter, Input, OnInit, Output } from '@angular/core';
import { Employee } from '../model/Employee';

@Component({
  selector: 'datatable',
  templateUrl: './datatable.component.html',
  styles: [
  ]
})
export class DatatableComponent implements OnInit {
  @Input() employees: Array<Employee>;
  @Output() onDelete: EventEmitter<number>;

  constructor() {
    this.employees = [];
    this.onDelete = new EventEmitter<number>();
  }

  ngOnInit(): void {
  }

  call_delete(id: number, e: Event) {
    e.preventDefault();
    this.onDelete.emit(id);
  }
}
