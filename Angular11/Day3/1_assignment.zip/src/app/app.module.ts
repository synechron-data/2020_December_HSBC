import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RootComponent } from './root/root.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { ValidationFormComponent } from './validation-form/validation-form.component';
import { FormComponent } from './form/form.component';
import { DatatableComponent } from './datatable/datatable.component';

@NgModule({
  declarations: [RootComponent, ValidationFormComponent, FormComponent, DatatableComponent],
  imports: [BrowserModule, FormsModule, ReactiveFormsModule],
  providers: [],
  bootstrap: [RootComponent]
})
export class AppModule { }
