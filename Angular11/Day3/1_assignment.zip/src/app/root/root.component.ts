import { Component, OnInit } from '@angular/core';
import { Employee } from '../model/Employee';

@Component({
  selector: 'root',
  templateUrl: './root.component.html',
  styles: [
  ]
})
export class RootComponent implements OnInit {
  empList: Array<Employee>;

  constructor() {
    this.empList = [];
  }

  ngOnInit(): void {
  }

  insert(employee: Employee) {
    // console.log("Insert: ", employee);
    this.empList.push(employee);
    // console.log(this.empList);
  }

  delete(id: number) {
    if (window.confirm("Are you sure you want to delete this record?"))
      this.empList = [...this.empList.filter(emp => emp.empid !== id)];
  }
}
