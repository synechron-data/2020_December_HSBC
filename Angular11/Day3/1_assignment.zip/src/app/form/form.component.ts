import { Component, OnInit, EventEmitter, Output } from '@angular/core';
import { FormBuilder, FormGroup, Validators } from '@angular/forms';
import { Employee } from '../model/Employee';

@Component({
  selector: 'form-component',
  templateUrl: './form.component.html',
  styles: [
  ]
})
export class FormComponent implements OnInit {
  @Output() onSave: EventEmitter<Employee>;
  empForm: FormGroup;

  get frm() { return this.empForm.controls; }

  constructor(private frmBuilder: FormBuilder) {
    this.empForm = this.frmBuilder.group({
      empid: [0, Validators.required],
      empname: ["", Validators.required],
      designation: ["", Validators.required],
      salary: [0, Validators.required]
    });

    this.onSave = new EventEmitter<Employee>();
  }

  ngOnInit(): void {
  }

  save() {
    if (this.empForm.valid) {
      this.onSave.emit(this.empForm.value);
      // console.log("Save Form: ", this.empForm.value);
    } else {
      this.empForm.markAllAsTouched();
      console.error("Invalid Employee Data");
    }
  }
}
