import { BrowserModule } from '@angular/platform-browser';
import { NgModule } from '@angular/core';
import { RootComponent } from './root/root.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { AsyncPromiseComponent } from './async-promise/async-promise.component';
import { AsyncObservableComponent } from './async-observable/async-observable.component';

@NgModule({
  declarations: [RootComponent, AsyncPromiseComponent, AsyncObservableComponent],
  imports: [BrowserModule, FormsModule, ReactiveFormsModule],
  bootstrap: [RootComponent]
})
export class AppModule { }
