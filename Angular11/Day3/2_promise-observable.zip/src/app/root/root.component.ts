import { THIS_EXPR } from '@angular/compiler/src/output/output_ast';
import { Component, OnInit } from '@angular/core';
import { observable, Observable, Observer, Subject, of, concat, empty } from 'rxjs';
import { filter, map, reduce, delay, startWith } from 'rxjs/operators';

@Component({
  selector: 'root',
  templateUrl: './root.component.html'
})
export class RootComponent implements OnInit {
  subject?: Subject<number>;
  observable?: Observable<number>;

  delayedMessage(message: any, delayTime = 1000) {
    return empty().pipe(startWith(message), delay(delayTime));
  }

  constructor() {
    // concat(
    //   this.delayedMessage('Get Ready'),
    //   this.delayedMessage(5),
    //   this.delayedMessage(4),
    //   this.delayedMessage(3),
    //   this.delayedMessage(2),
    //   this.delayedMessage(1),
    //   this.delayedMessage('Go'),
    // ).subscribe((message: any) => console.log(message));
    // concat(
    //   of(10,20,30),
    //   of(40,50,60)
    // ).subscribe(console.log);

    // let numberOb = of(10, 20, 33, 40, 53, 60, 73);

    // // numberOb.subscribe(n => console.log(n));

    // let evenOb = numberOb.pipe(
    //   filter(n => n % 2 == 0),
    //   map(n => n * 10),
    //   reduce((acc, n) => acc + n)
    // );

    // evenOb.subscribe(n => console.log(n));

    // this.observable = this.getSubjectObservale();

    // this.observable.subscribe((data) => {
    //   console.log("Subscriber 1, Output - ", data);
    // });

    // this.observable.subscribe((data) => {
    //   console.log("Subscriber 2, Output - ", data);
    // });

    // this.subject = this.getSubject();

    // this.subject.subscribe((data) => {
    //   console.log("Subscriber 1, Output - ", data);
    // });

    // this.subject.subscribe((data) => {
    //   console.log("Subscriber 2, Output - ", data);
    // });

    // this.getObservable().subscribe((data) => {
    //   console.log("Subscriber 1, Output - ", data);
    // }, (err) => {
    //   console.error("Observable Error - ", err);
    // });

    // this.getObservable().subscribe((data) => {
    //   console.log("Subscriber 2, Output - ", data);
    // }, (err) => {
    //   console.error("Observable Error - ", err);
    // });

    // this.getObservable().subscribe((data) => {
    //   console.log("Observable Output - ", data);
    // }, (err) => {
    //   console.error("Observable Error - ", err);
    // });

    // this.getPromise().then((data) => {
    //   console.log("Promise Output - ", data);
    // }, (err) => {
    //   console.error("Promise Error - ", err);
    // });
  }

  ngOnInit(): void {
  }

  getSubjectObservale(): Observable<number> {
    let s = new Subject<number>();

    setInterval(() => {
      s.next(Math.random());
    }, 2000);

    return s.asObservable();
  }

  getSubject(): Subject<number> {
    let s = new Subject<number>();

    setInterval(() => {
      s.next(Math.random());
    }, 2000);

    return s;
  }

  getObservable(): Observable<number> {
    return Observable.create((ob: Observer<number>) => {
      setInterval(function () {
        ob.next(Math.random());
      }, 2000);
    });
  }

  getPromise(): Promise<number> {
    return new Promise((resolve, reject) => {
      setInterval(function () {
        // console.log("Set Interval Executed...");
        resolve(Math.random());
      }, 2000);
    });
  }
}
