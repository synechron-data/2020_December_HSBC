// Generics allows you to create a component that can work over a variety of types
// rather than a single one, without loosing type safety and intellisense

// class Queue {
//     private _data: number[] = [];

//     push(d: number) {
//         this._data.push(d);
//     }

//     pop(): number | undefined {
//         return this._data.shift();
//     }
// }

// var numbersQ = new Queue();

// numbersQ.push(10);
// numbersQ.push(20);
// numbersQ.push(30);

// console.log(numbersQ.pop());
// console.log(numbersQ.pop());
// console.log(numbersQ.pop());

// ---------------------------------------------------- Flexibility, we can use 'any' as a type

// class Queue {
//     private _data: any[] = [];

//     push(d: any) {
//         this._data.push(d);
//     }

//     pop(): any | undefined {
//         return this._data.shift();
//     }
// }

// var numbersQ = new Queue();

// numbersQ.push(10);
// numbersQ.push(20);
// numbersQ.push(30);

// console.log(numbersQ.pop());
// console.log(numbersQ.pop());
// console.log(numbersQ.pop());

// var namesQ = new Queue();

// namesQ.push("abc");
// namesQ.push("pqr");
// namesQ.push(10);

// console.log(namesQ.pop().toUpperCase());
// console.log(namesQ.pop().toUpperCase());
// console.log(namesQ.pop().toUpperCase());

// ------------------------------------------------------------- Generic

// class Queue<T> {
//     private _data: T[] = [];

//     push(d: T) {
//         this._data.push(d);
//     }

//     pop(): T | undefined {
//         return this._data.shift();
//     }
// }

// var numbersQ = new Queue<number>();

// numbersQ.push(10);
// numbersQ.push(20);
// numbersQ.push(30);

// console.log(numbersQ.pop());
// console.log(numbersQ.pop());
// console.log(numbersQ.pop());

// var namesQ = new Queue<string>();

// namesQ.push("abc");
// namesQ.push("pqr");

// console.log((<string>namesQ.pop()).toUpperCase());
// console.log((<string>namesQ.pop()).toUpperCase());

// -------------------------------------------------------- Constraints
interface ILength {
    length: number;
}

function getLength<T extends ILength>(arg: T) {
    return arg.length;
}

console.log(getLength<string>("Manish"));
console.log(getLength<string[]>(["Manish"]));
console.log(getLength<number[]>([10, 20, 30, 40, 50]));

// console.log(getLength<number>(10));
