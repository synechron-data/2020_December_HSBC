// interface IPerson {
//     name: string;
//     age: number;
//     greet: (message: string) => string;
// }

// class Person implements IPerson {
//     constructor(public name: string, public age: number) { }

//     greet(message: string): string {
//         return "Hello";
//     }
// }

// let p1: IPerson = new Person("Abhijeet", 38);
// console.log(p1.greet("Hi"));

// let p2: IPerson = new Person("Ramakant", 39);
// console.log(p2.greet("Hi"));

// ------------------------------------------------------- Multiple Interface Implementation

// interface IPerson {
//     name: string;
//     age: number;
//     greet: (message: string) => string;
// }

// interface IWork {
//     doWork(): string;
// }

// class Person implements IPerson, IWork {
//     constructor(public name: string, public age: number) { }

//     greet(message: string): string {
//         return "Hello";
//     }

//     doWork(): string {
//         return "I am learning TypeScript";
//     }
// }

// let p1: Person = new Person("Abhijeet", 38);
// console.log(p1.greet("Hi"));
// console.log(p1.doWork());

// ------------------------------------------------------- Multiple Interface Implementation

// interface IPerson {
//     name: string;
//     age: number;
//     greet: (message: string) => string;
// }

// interface IWork {
//     doWork(): string;
// }

// // interface ICustomer {
// //     doShopping(): string;
// // }

// interface ICustomer extends IPerson {
//     doShopping(): string;
// }

// class Person implements IPerson, IWork, ICustomer {
//     constructor(public name: string, public age: number) { }

//     greet(message: string): string {
//         return "Hello";
//     }

//     doWork(): string {
//         return "I am learning TypeScript";
//     }

//     doShopping(): string {
//         return "Let's to it online";
//     }
// }

// // let p1: Person = new Person("Abhijeet", 38);
// // console.log(p1.greet("Hi"));
// // console.log(p1.doWork());
// // console.log(p1.doShopping());

// // let p1: IPerson = new Person("Abhijeet", 38);
// // console.log(p1.greet("Hi"));

// // let p1: IWork = new Person("Abhijeet", 38);
// // console.log(p1.doWork());

// // let p1: ICustomer = new Person("Abhijeet", 38);
// // console.log(p1.doShopping());

// let p1: ICustomer = new Person("Abhijeet", 38);
// console.log(p1.greet("Hi"));
// console.log(p1.doShopping());

// --------------------------------------------------------------- Interface can extend from Class(s)
// class Developer {
//     applyLeave() {
//         console.log("Leave applied...");
//     }
// }

// class Manager {
//     approveLeave() {
//         console.log("Leave approved...");
//     }
// }

// class DevMan extends Developer, Manager {

// }

// var d = new DevMan();
// d.applyLeave();
// d.approveLeave();

// ----------------------------------

// class Cashier {
//     applyLoan() {
//         console.log("Loan applied...");
//     }
// }

// class BManager {
//     approveLoan() {
//         console.log("Loan approved...");
//     }
// }

// class CashMan extends Cashier, BManager {

// }

// var d = new CashMan();
// d.applyLoan();
// d.approveLoan();

// ---------------------------------------------------------- Interface can extend from Class(s)
class Cashier {
    applyLoan() {
        console.log("Loan applied...");
    }
}

class BManager {
    applyLoan() {
        console.log("Loan applied...");
    }
    
    approveLoan() {
        console.log("Loan approved...");
    }
}

interface IBankManager extends Cashier, BManager { }

class BankManager implements IBankManager {
    applyLoan(): void {
        throw new Error("Method not implemented.");
    }

    approveLoan(): void {
        throw new Error("Method not implemented.");
    }
}

var d = new BankManager();
d.applyLoan();
d.approveLoan();