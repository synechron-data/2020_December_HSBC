"use strict";
var Cashier = (function () {
    function Cashier() {
    }
    Cashier.prototype.applyLoan = function () {
        console.log("Loan applied...");
    };
    return Cashier;
}());
var BManager = (function () {
    function BManager() {
    }
    BManager.prototype.applyLoan = function () {
        console.log("Loan applied...");
    };
    BManager.prototype.approveLoan = function () {
        console.log("Loan approved...");
    };
    return BManager;
}());
var BankManager = (function () {
    function BankManager() {
    }
    BankManager.prototype.applyLoan = function () {
        throw new Error("Method not implemented.");
    };
    BankManager.prototype.approveLoan = function () {
        throw new Error("Method not implemented.");
    };
    return BankManager;
}());
var d = new BankManager();
d.applyLoan();
d.approveLoan();
