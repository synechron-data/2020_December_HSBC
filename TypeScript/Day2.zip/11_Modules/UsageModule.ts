// import { IPoint, Point } from './PointModule';
// let point: IPoint = new Point(2, 3);
// console.log(point.getDistance());

// import * as pm from './PointModule';
// let point: pm.IPoint = new pm.Point(2, 3);
// console.log(point.getDistance());

// --------------------------------------- Code for Browser

import { IPoint, Point } from './PointModule.js';
import * as $ from "jquery";

let point: IPoint = new Point(2, 3);
console.log(point.getDistance());

document.getElementById("jsResult").innerHTML =
    point.getDistance().toString();

$(document).ready(() => {
    $("#jqResult").html(point.getDistance().toString());
});

// npm i systemjs@0.21
// Refer and Use System JS on HTML Page

// npm install -g http-server
// http-server .

// npm i jquery
// npm i -D @types/jquery

// Create a systemjs.config.js

// Import jquery and use it